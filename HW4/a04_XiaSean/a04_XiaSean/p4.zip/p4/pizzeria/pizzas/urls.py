# from django.urls import path
from django.urls import path, re_path
from . import views

app_name = 'pizzas'
urlpatterns = [
    path('', views.index, name='index'),
    path('pizzas/', views.pizzas, name='pizzas'),
    re_path(r'^pizzas/(?P<pizza_id>\d+)/$', views.toppings, name='toppings'),
]