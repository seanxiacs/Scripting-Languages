# Pizzeria Project

## Author
Name: Sean Xia
NetID: sexia
Student ID: 113181409

## Description
This project is a simple Django web application for a pizzeria. Users can view a list of available pizzas and see their toppings. The project was developed using Django 2.2 and Python 3.